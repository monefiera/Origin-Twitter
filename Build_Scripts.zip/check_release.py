import requests
import os

GITHUB_REPO = "crimera/twitter-apk"
GITHUB_API_URL = f"https://api.github.com/repos/{GITHUB_REPO}/releases/latest"
OUTPUT_DIR = "downloads"
APK_NAME = "twitter-piko"
TOKEN = "null"

def get_latest_release():
    headers = {"Authorization": f"token {TOKEN}"}
    response = requests.get(GITHUB_API_URL, headers=headers)
    response.raise_for_status()
    return response.json()

def download_apk(release):
    for asset in release["assets"]:
        if APK_NAME in asset["name"] and asset["name"].endswith(".apk"):
            url = asset["browser_download_url"]
            apk_path = os.path.join(OUTPUT_DIR, asset["name"])
            os.makedirs(OUTPUT_DIR, exist_ok=True)
            with requests.get(url, stream=True) as r:
                r.raise_for_status()
                with open(apk_path, "wb") as f:
                    for chunk in r.iter_content(chunk_size=8192):
                        f.write(chunk)
            return apk_path
    return None

if __name__ == "__main__":
    latest_release = get_latest_release()
    apk_path = download_apk(latest_release)
    print(f"Downloaded: {apk_path}")
